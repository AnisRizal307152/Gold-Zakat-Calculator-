package com.example.individualassignmentict602;

//import the necessary Android and Java framework libraries
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;



/**
 * MainActivity for the Gold Zakat Calculator application.
 * This class handles the UI logic for calculating gold zakat based on weight and value per gram,
 * considering the threshold (X) for gold kept (85g) vs gold worn (200g).
 */
//Declares primary screen class
public class MainActivity extends AppCompatActivity {

    //Declares variable
    private EditText editWeight, editValue;
    private RadioGroup radioGroupType;
    private TextView textTotalValue, textUruf, textZakatPayable, textTotalZakat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); //Overrides the default lifecycle method
        // Enable edge-to-edge display make full screen feature
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // make status bar or navigation bar do not overlap your UI layout elements
        View mainView = findViewById(R.id.main);
        if (mainView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        // Setup the Toolbar
        //custom top action bar/toolbar using its ID and sets the app title dynamically
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.app_name);
        }

        // Initialize UI component references
        //Links the global variables declared at the top of the class
        editWeight = findViewById(R.id.editWeight);
        editValue = findViewById(R.id.editValue);
        radioGroupType = findViewById(R.id.radioGroupType);
        textTotalValue = findViewById(R.id.textTotalValue);
        textUruf = findViewById(R.id.textUruf);
        textZakatPayable = findViewById(R.id.textZakatPayable);
        textTotalZakat = findViewById(R.id.textTotalZakat);
        Button btnCalculate = findViewById(R.id.btnCalculate);
        Button btnClear = findViewById(R.id.btnClear);

        //image as share and info button
        ImageView imgShare = findViewById(R.id.imgShare);
        ImageView imgInfo = findViewById(R.id.imgInfo);

        if (imgShare != null) { //makesure app wont crush
            imgShare.setOnClickListener(v -> { //user need to tap first
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND); // take the text string and open system share system
                sendIntent.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_text));
                sendIntent.setType("text/plain");
                startActivity(Intent.createChooser(sendIntent, "Share via"));
            });
        }

        // click icon then dialog box will appear with developer info
        if (imgInfo != null) {
            imgInfo.setOnClickListener(v -> {

                //  information
                String infoText = "Name: Anis Rizal<br>" +
                        "Student ID: 2025197183<br>" +
                        "Course: ICT602<br>" +
                        "Application: Gold Zakat Calculator<br>" +
                        "Github: <a href='https://github.com/your-username/your-repo'>View Repository</a>";

                //  TextView that knows how to make links clickable
                android.widget.TextView messageView = new android.widget.TextView(this);
                messageView.setText(android.text.Html.fromHtml(infoText, android.text.Html.FROM_HTML_MODE_LEGACY));
                messageView.setMovementMethod(android.text.method.LinkMovementMethod.getInstance()); // This makes the link clickable!
                messageView.setPadding(64, 32, 64, 32); // Adds some nice breathing room around the text
                messageView.setTextSize(16f);

                //  Show the dialog using .setView() instead of .setMessage()
                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Developer Information")
                        .setView(messageView) //  custom clickable text view here
                        .setPositiveButton("OK", null)
                        .show();
            });
        }

        // Set Click Listeners
        if (btnCalculate != null) {
            btnCalculate.setOnClickListener(v -> calculateZakat()); //calculate the zakat
        }

        if (btnClear != null) {
            btnClear.setOnClickListener(v -> clearFields()); // clear the data
        }
    }

    /**
     * Resets all input fields and results to their default states.
     */
    private void clearFields() { //reset input text area
        if (editWeight != null) editWeight.setText("");
        if (editValue != null) editValue.setText("");
        if (radioGroupType != null) radioGroupType.check(R.id.radioKeep);
        if (textTotalValue != null) textTotalValue.setText(getString(R.string.default_total_value));
        if (textUruf != null) textUruf.setText(getString(R.string.default_uruf));
        if (textZakatPayable != null) textZakatPayable.setText(getString(R.string.default_zakat_payable));
        if (textTotalZakat != null) textTotalZakat.setText(getString(R.string.default_total_zakat));
    }

    /**
     * Performs the zakat calculation based on user input and the provided logic:
     * 1. Total Value = weight * value
     * 2. Uruf (Weight minus X) = weight - X (where X=85 for keep, X=200 for wear)
     * 3. Zakat Payable = Uruf * value
     * 4. Total Zakat = 2.5% * Zakat Payable
     */
    private void calculateZakat() { //check what user click keep or wear
        if (editWeight == null || editValue == null || radioGroupType == null) return;

        String weightStr = editWeight.getText().toString().trim();
        String valueStr = editValue.getText().toString().trim();
        //extract user data - convert text string

        if (weightStr.isEmpty() || valueStr.isEmpty()) {
            Toast.makeText(this, "Please enter both weight and value", Toast.LENGTH_SHORT).show();
            return; //quick pop up notification if user dont input data
        }

        try {
            //convert string to double
            double weight = Double.parseDouble(weightStr);
            double valuePerGram = Double.parseDouble(valueStr);

            // X value: 85g for keep, 200g for wear
            int selectedId = radioGroupType.getCheckedRadioButtonId();
            double threshold = (selectedId == R.id.radioKeep) ? 85.0 : 200.0;

            //total value of the gold
            double totalValue = weight * valuePerGram;

            //  calculate uruf - Zakat Payable Value
            double uruf = weight - threshold; //weight need to pay zakat follow uruf(can be negative)
            //keep (-85g) and wear (-200g)
            double weightSubjectToZakat = Math.max(0.0, uruf);//if weight lees than uruf no need to pay zakat
            double zakatPayableValue = weightSubjectToZakat * valuePerGram;//calculate payable zakat

            // The total zakat (2.5%)
            double totalZakat = zakatPayableValue * 0.025;

            // call the data as output
            if (textTotalValue != null)
                textTotalValue.setText(getString(R.string.result_total_value, totalValue));
            if (textUruf != null)
                textUruf.setText(getString(R.string.result_uruf, uruf));
            if (textZakatPayable != null)
                textZakatPayable.setText(getString(R.string.result_zakat_payable, zakatPayableValue));
            if (textTotalZakat != null)
                textTotalZakat.setText(getString(R.string.result_total_zakat, totalZakat));

            //error when user incorrect input
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter valid numerical values", Toast.LENGTH_SHORT).show();
        }
    }

}
